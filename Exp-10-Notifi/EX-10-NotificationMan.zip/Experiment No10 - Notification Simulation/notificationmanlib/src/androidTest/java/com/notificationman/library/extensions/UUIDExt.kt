package com.notificationman.library.extensions

import java.util.*

fun getRandomUUID(): UUID = UUID.randomUUID()